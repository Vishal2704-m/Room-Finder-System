package servlet_connecction;

import java.io.File;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.model.Owner;

import dao_classes.OwnerDao;
@MultipartConfig(maxFileSize = 1024 * 1024 * 5)
@WebServlet("/req1")
public class OwnerLoginServlet  extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String name = req.getParameter("name");
		String mnumber = req.getParameter("mnumber");
		double latitude = Double.parseDouble(req.getParameter("latitude"));
		double  langitude = Double.parseDouble(req.getParameter("langitude"));
		int roomrent = Integer.parseInt(req.getParameter("roomrent"));
		String password = req.getParameter("password");
		
		Part photo1 = req.getPart("image1");
		Part photo2 = req.getPart("image2");
		
		String room_type=req.getParameter("room_type");
		
		String firstfilename="owner_"+System.currentTimeMillis()+photo1.getSubmittedFileName();
		String secondfilename="owner_"+System.currentTimeMillis()+photo2.getSubmittedFileName();
	
		String folderpath = getServletContext().getRealPath("/upload");
		
		File f = new File(folderpath);
		if(!f.exists())f.mkdir();
		
		photo1.write(folderpath+File.separator+firstfilename);
		photo2.write(folderpath+File.separator+secondfilename);
		System.out.println("room_for"+room_type);
		System.out.println(folderpath+File.separator+firstfilename);
		
		String firstphoto="upload/"+firstfilename;
		String secondphoto="upload/"+secondfilename;
		
		Owner o = new Owner();
		o.setOname(name);
		o.setOnumber(mnumber);
		o.setLatitude(latitude);
		o.setLangitude(langitude);
		o.setImage1(firstphoto);
		o.setImage2(secondphoto);
		o.setRoomrent(roomrent);
		o.setOpassword(password);
		o.setRoom_type(room_type);
	
		
		int result = OwnerDao.insertOwner(o);
		if(result>0) {
			System.out.print("data inserted");
			resp.sendRedirect("map.html");
		}
		
	}

}
