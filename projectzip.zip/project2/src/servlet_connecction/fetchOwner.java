package servlet_connecction;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Owner;

import dao_classes.OwnerDao;
@WebServlet("/getOwner")
public class fetchOwner extends HttpServlet {
	protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		res.setContentType("application/json");
		List<Owner> list = OwnerDao.getAllOwner();
		PrintWriter out = res.getWriter();
		out.print("[");
		for(int i=0;i<list.size();i++)
		{
			Owner o = list.get(i);
			out.print("{");
			out.print("\"id\":"+o.getId()+",");
			out.print("\"name\":\""+o.getOname()+"\",");
			out.print("\"onumber\":\""+o.getOnumber()+"\",");
			out.print("\"latitude\":"+o.getLatitude()+",");
			out.print("\"langitude\":"+o.getLangitude()+",");
			out.print("\"photo1\":\""+o.getImage1()+"\",");
			out.print("\"photo2\":\""+o.getImage2()+"\",");
			out.print("\"roomtype\":\""+o.getRoom_type()+"\",");
			out.print("\"roomrent\":"+o.getRoomrent());
			out.print("}");

				if(i<list.size()-1)
					out.print(",");
		}
		out.print("]");
	}

}
