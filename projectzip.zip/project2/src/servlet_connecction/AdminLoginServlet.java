package servlet_connecction;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/req4")
public class AdminLoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		String action = req.getParameter("action");
		HttpSession session = req.getSession();

		// SEND OTP
		if ("send".equals(action)) {

			String email = req.getParameter("email");

			if (email.equals("mahajanvishal865@gmail.com")) {

				// Generate OTP
				Random random = new Random();
				int otp = 100000 + random.nextInt(900000);

				session.setAttribute("otp", otp);

				String from = "mahajanvishal865@gmail.com";
				String password = "cdmu liul bpev ivup"; // Gmail App Password

				Properties props = new Properties();
				props.put("mail.smtp.auth", "true");
				props.put("mail.smtp.starttls.enable", "true");
				props.put("mail.smtp.host", "smtp.gmail.com");
				props.put("mail.smtp.port", "587");

				Session mailSession = Session.getInstance(props,
						new javax.mail.Authenticator() {
							protected PasswordAuthentication getPasswordAuthentication() {
								return new PasswordAuthentication(from, password);
							}
						});

				try {

					Message message = new MimeMessage(mailSession);

					message.setFrom(new InternetAddress(from));

					message.setRecipients(
							Message.RecipientType.TO,
							InternetAddress.parse(email)
					);

					message.setSubject("Admin Login OTP");

					message.setText("Your OTP is: " + otp);

					Transport.send(message);

					// redirect to OTP page
					res.sendRedirect("otp.html");

				} catch (Exception e) {
					out.println("Error: " + e);
				}

			} else {

				out.println("<h3>Invalid Admin Email</h3>");

			}
		}

		// VERIFY OTP
		else if ("verify".equals(action)) {

			int userOtp = Integer.parseInt(req.getParameter("otp"));
			int otp = (int) session.getAttribute("otp");

			if (userOtp == otp) {

				out.println("<h2>Admin Login Successful</h2>");
				res.sendRedirect("Admin.html");

			} else {

				out.println("<h2>Invalid OTP</h2>");

			}
		}
	}
}