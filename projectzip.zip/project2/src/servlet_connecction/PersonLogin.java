package servlet_connecction;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Person;

import dao_classes.PersonDao;
@WebServlet("/req2")
public class PersonLogin extends HttpServlet{
	protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		String uname=req.getParameter("name");
		String unumber=req.getParameter("mobile");
		String email=req.getParameter("email");
		String upassword=req.getParameter("password");
		
		Person p = new Person();
		p.setUname(uname);
		p.setUnumber(unumber);
		p.setEmail(email);
		p.setUpassword(upassword);
		int value=0;
		PersonDao p1 = new PersonDao();
		value=p1.insertPerson(p);
		System.out.println("value of "+value);
		if(value>0)
			res.sendRedirect("index.html");
	}

}
