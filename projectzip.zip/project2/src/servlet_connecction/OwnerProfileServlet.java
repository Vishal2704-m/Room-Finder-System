package servlet_connecction;


import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.model.Owner;

@WebServlet("/OwnerProfileServlet")

public class OwnerProfileServlet extends HttpServlet {

protected void doGet(HttpServletRequest request,
HttpServletResponse response) throws IOException{

response.setContentType("application/json");

HttpSession session=request.getSession(false);

Owner o=(Owner)session.getAttribute("owner");

String json="{"+
"\"name\":\""+o.getOname()+"\","+
"\"phone\":\""+o.getOnumber()+"\","+
"\"rent\":\""+o.getRoomrent()+"\","+
"\"img1\":\""+o.getImage1()+"\","+
"\"img2\":\""+o.getImage2()+"\""+
"}";

response.getWriter().print(json);

}

}
