package servlet_connecction;
import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao_classes.OwnerDao;
import com.model.Owner;
@WebServlet("/OwnerLoginServlet")
public class OwnerDashboardLoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws IOException{

			String number=request.getParameter("onumber");
			String password=request.getParameter("opassword");

			Owner o=OwnerDao.loginOwner(number,password);

			if(o!=null){

			HttpSession session=request.getSession();

			session.setAttribute("owner",o);

			response.sendRedirect("ownerAvailableStatus.html");

			}else{

			response.getWriter().println("Login Failed");

			}

			}

}
