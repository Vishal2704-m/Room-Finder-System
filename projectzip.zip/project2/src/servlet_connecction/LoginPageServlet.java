package servlet_connecction;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/req3")
public class LoginPageServlet extends HttpServlet {
	protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		String uemail=req.getParameter("email");
		String upassword=req.getParameter("password");
		String dbpassword = null;
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","yuvi@123");
			String sql="select upassword from person where umail=?";
			pst=con.prepareStatement(sql);
			pst.setString(1,uemail);
			rs=pst.executeQuery();
			if(rs.next())
			{
				dbpassword=(String)rs.getObject("upassword");
			}
			
			if(uemail.equals("admin123@gmail.com")&&upassword.equals("ADMIN"))
			{
				res.sendRedirect("Admin.html");
			}
			else if(upassword.equals(dbpassword))
			{
				res.sendRedirect("map.html");
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				rs.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}
}
