package servlet_connecction;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Person;

import dao_classes.PersonDao;

@WebServlet("/getPerson")
public class fetchPerson extends HttpServlet{
	protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		res.setContentType("application/json");
		List<Person> list = PersonDao.getAllUser();
		PrintWriter out = res.getWriter();
		out.print("[");
		for(int i=0;i<list.size();i++)
		{
		    Person p = list.get(i);   
		    out.print("{");
		    out.print("\"id\":"+p.getId()+",");
		    out.print("\"name\":\""+p.getUname()+"\",");
		    out.print("\"email\":\""+p.getEmail()+"\",");
		    out.print("\"roomrent\":\""+p.getUnumber()+"\"");
		    out.print("}");

		    if(i<list.size()-1)
		        out.print(",");
		}
		out.print("]");
	}

}
