package servlet_connecction;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deleteOwner")
public class DeleteOwner extends HttpServlet{
	protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		int id = Integer.parseInt(req.getParameter("id"));
		
		Connection con = null;
		PreparedStatement pst = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","yuvi@123");
			
			String sql="delete from roomowner where id =?";
			pst=con.prepareStatement(sql);
			
			 pst.setInt(1, id); 

	            int rows = pst.executeUpdate();

	            if(rows > 0){
	                res.getWriter().print("success");
	            }else{
	                res.getWriter().print("failed");
	            }
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
}
