package dao_classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Owner;

public class OwnerDao {
	public static int insertOwner(Owner o)
	{
		int result=0;
		Connection con = null;
		PreparedStatement pst = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","yuvi@123");
			String sql="insert into roomowner(oname,onumber,latitude,langitude,photo1,photo2,roomrent,opassword,room_type)values(?,?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(sql);
			pst.setString(1,o.getOname());
			pst.setString(2, o.getOnumber());
			pst.setDouble(3, o.getLatitude());
			pst.setDouble(4, o.getLangitude());
			pst.setString(5, o.getImage1());
			pst.setString(6, o.getImage2());
			pst.setInt(7, o.getRoomrent());
			pst.setString(8, o.getOpassword());
			pst.setString(9, o.getRoom_type());
			
			result=pst.executeUpdate();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			
		}
		return result;
	}
	public static List<Owner> getAllOwner()
	{
		List<Owner> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pst=null;
		ResultSet rs= null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","yuvi@123");
			String sql="select id,oname,onumber,latitude,langitude,photo1,photo2,roomrent,opassword,room_type from roomowner";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();
			while(rs.next())
			{
				Owner o = new Owner();
				o.setId((int)rs.getObject("id"));
				o.setOname((String)rs.getObject("oname"));
				o.setOnumber((String)rs.getObject("onumber"));
				o.setLatitude((double)rs.getObject("latitude"));
				o.setLangitude((double)rs.getObject("langitude"));
				o.setImage1((String)rs.getObject("photo1"));
				o.setImage2((String)rs.getObject("photo2"));
				o.setRoomrent((int)rs.getObject("roomrent"));
				o.setOpassword((String)rs.getObject("opassword"));
				o.setRoom_type((String)rs.getObject(("room_type")));
				list.add(o);
				
			}
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return list;
	}
	public static Owner loginOwner(String number,String password){

		Owner o=null;

		try{

		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection con=DriverManager.getConnection(
		"jdbc:mysql://localhost:3306/project","root","yuvi@123");

		String sql="select * from roomowner where onumber=? and opassword=?";

		PreparedStatement pst=con.prepareStatement(sql);

		pst.setString(1,number);
		pst.setString(2,password);

		ResultSet rs=pst.executeQuery();

		if(rs.next()){

		o=new Owner();

		o.setId(rs.getInt("id"));
		o.setOname(rs.getString("oname"));
		o.setOnumber(rs.getString("onumber"));
		o.setRoomrent(rs.getInt("roomrent"));
		o.setImage1(rs.getString("photo1"));
		o.setImage2(rs.getString("photo2"));

		}

		}catch(Exception e){
		e.printStackTrace();
		}

		return o;
		}
}
