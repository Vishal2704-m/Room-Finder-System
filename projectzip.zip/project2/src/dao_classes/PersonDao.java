package dao_classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Person;

public class PersonDao {
	public int insertPerson(Person p)
	{
		int result=0;
		Connection con=null;
		PreparedStatement pst=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","yuvi@123");
			String sql="insert into person(uname,umail,unumber,upassword)values(?,?,?,?)";
			
			pst=con.prepareStatement(sql);
			pst.setString(1,p.getUname());
			pst.setString(2,p.getEmail());
			pst.setString(3,p.getUnumber());
			pst.setString(4,p.getUpassword());
			
			result=pst.executeUpdate();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				pst.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	public static List<Person> getAllUser()
	{
		List<Person> list = new ArrayList<>();
		
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","yuvi@123");
			String sql="select id,uname,umail,unumber,upassword from person";
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();
			while(rs.next())
			{
				Person p = new Person();
				p.setId((int)rs.getObject("id"));
				p.setUname((String)rs.getObject("uname"));
				p.setUnumber((String)rs.getObject("unumber"));
				p.setEmail((String)rs.getObject("umail"));
				p.setUpassword((String)rs.getObject("upassword"));
				list.add(p);
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {
				rs.close();
				pst.close();
				con.close();
				} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return list;
	}

}
