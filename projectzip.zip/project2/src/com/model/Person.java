package com.model;

public class Person {
	private int id;
	private String uname;
	private String email;
	private String unumber;
	private String upassword;
	public void setId(int id) {
		this.id = id;
	}
	
	
	public void setUname(String uname) {
		this.uname = uname;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public void setUnumber(String unumber) {
		this.unumber = unumber;
	}
	public void setUpassword(
			String upassword) {
		this.upassword = upassword;
	}
	public int getId() {
		return id;
	}
	public String getUname() {
		return uname;
	}
	public String getEmail() {
		return email;
	}
	public String getUnumber() {
		return unumber;
	}
	public String getUpassword() {
		return upassword;
	}
	

}
