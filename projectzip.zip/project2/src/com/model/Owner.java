package com.model;

public class Owner {
	private int id;
	private String oname;
	private String onumber;
	private double latitude;
	private double langitude;
	private int roomrent;
	private String opassword;
	private String image1;
	private String image2;
	private String room_type;
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImage1() {
		return image1;
	}
	public void setImage1(String image1) {
		this.image1 = image1;
	}
	public String getImage2() {
		return image2;
	}
	public void setImage2(String image2) {
		this.image2 = image2;
	}
	public String getOname() {
		return oname;
	}
	public void setOname(String oname) {
		this.oname = oname;
	}
	public String getOnumber() {
		return onumber;
	}
	public void setOnumber(String onumber) {
		this.onumber = onumber;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLangitude() {
		return langitude;
	}
	public void setLangitude(double langitude) {
		this.langitude = langitude;
	}
	public int getRoomrent() {
		return roomrent;
	}
	public void setRoomrent(int roomrent) {
		this.roomrent = roomrent;
	}
	public String getOpassword() {
		return opassword;
	}
	public void setOpassword(String opassword) {
		this.opassword = opassword;
	}
	
		

}
